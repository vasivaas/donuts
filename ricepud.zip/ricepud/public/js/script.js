import Game from './Game.js';

var game = Game.create(500, 570);
